from flask import Blueprint, request, jsonify
import time
import random
from src.services.ai_models import ai_service

code_generator_bp = Blueprint('code_generator', __name__)

# قائمة النماذج المدعومة
SUPPORTED_MODELS = {
    'openai-codex': {
        'name': 'OpenAI Codex',
        'description': 'نموذج OpenAI المتخصص في توليد الأكواد',
        'languages': ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'Ruby', 'Swift', 'Kotlin']
    },
    'code-llama': {
        'name': 'Code Llama',
        'description': 'نموذج Meta المفتوح المصدر لتوليد الأكواد',
        'languages': ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'Ruby']
    },
    'starcoder': {
        'name': 'StarCoder',
        'description': 'نموذج BigCode المتخصص في أكثر من 80 لغة برمجة',
        'languages': ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'Ruby', 'Swift', 'Kotlin', 'Dart', 'SQL']
    },
    'deepseek-coder': {
        'name': 'DeepSeek Coder',
        'description': 'نموذج DeepSeek المتقدم لتوليد الأكواد',
        'languages': ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'Ruby', 'Swift', 'Kotlin']
    },
    'chatgpt': {
        'name': 'ChatGPT',
        'description': 'نموذج OpenAI متعدد الاستخدامات مع قدرات برمجية',
        'languages': ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'Ruby', 'Swift', 'Kotlin', 'Dart', 'SQL', 'HTML', 'CSS']
    },
    'claude': {
        'name': 'Claude',
        'description': 'نموذج Anthropic المتقدم مع قدرات برمجية عالية',
        'languages': ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'Ruby', 'Swift', 'Kotlin', 'Dart', 'SQL']
    },
    'manus': {
        'name': 'Manus',
        'description': 'وكيل الذكاء الاصطناعي العام المتخصص في التطوير',
        'languages': ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'Ruby', 'Swift', 'Kotlin', 'Dart', 'SQL', 'HTML', 'CSS']
    }
}

# أمثلة أكواد لكل لغة برمجة
CODE_EXAMPLES = {
    'Python': {
        'fibonacci': '''def fibonacci(n):
    """
    توليد متتالية فيبوناتشي حتى العدد n
    """
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    
    sequence = [0, 1]
    for i in range(2, n):
        sequence.append(sequence[i-1] + sequence[i-2])
    
    return sequence

# استخدام الدالة
result = fibonacci(10)
print(f"أول 10 أرقام في متتالية فيبوناتشي: {result}")''',
        'sorting': '''def bubble_sort(arr):
    """
    ترتيب المصفوفة باستخدام خوارزمية الفقاعة
    """
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

# مثال على الاستخدام
numbers = [64, 34, 25, 12, 22, 11, 90]
sorted_numbers = bubble_sort(numbers.copy())
print(f"المصفوفة الأصلية: {numbers}")
print(f"المصفوفة مرتبة: {sorted_numbers}")''',
        'calculator': '''class Calculator:
    """
    آلة حاسبة بسيطة تدعم العمليات الأساسية
    """
    
    def add(self, a, b):
        return a + b
    
    def subtract(self, a, b):
        return a - b
    
    def multiply(self, a, b):
        return a * b
    
    def divide(self, a, b):
        if b == 0:
            raise ValueError("لا يمكن القسمة على صفر")
        return a / b

# استخدام الآلة الحاسبة
calc = Calculator()
print(f"5 + 3 = {calc.add(5, 3)}")
print(f"10 - 4 = {calc.subtract(10, 4)}")
print(f"6 * 7 = {calc.multiply(6, 7)}")
print(f"15 / 3 = {calc.divide(15, 3)}")'''
    },
    'JavaScript': {
        'fibonacci': '''function fibonacci(n) {
    /**
     * توليد متتالية فيبوناتشي حتى العدد n
     */
    if (n <= 0) return [];
    if (n === 1) return [0];
    if (n === 2) return [0, 1];
    
    const sequence = [0, 1];
    for (let i = 2; i < n; i++) {
        sequence.push(sequence[i-1] + sequence[i-2]);
    }
    
    return sequence;
}

// استخدام الدالة
const result = fibonacci(10);
console.log(`أول 10 أرقام في متتالية فيبوناتشي: ${result}`);''',
        'sorting': '''function bubbleSort(arr) {
    /**
     * ترتيب المصفوفة باستخدام خوارزمية الفقاعة
     */
    const n = arr.length;
    const sortedArr = [...arr];
    
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n - i - 1; j++) {
            if (sortedArr[j] > sortedArr[j + 1]) {
                [sortedArr[j], sortedArr[j + 1]] = [sortedArr[j + 1], sortedArr[j]];
            }
        }
    }
    
    return sortedArr;
}

// مثال على الاستخدام
const numbers = [64, 34, 25, 12, 22, 11, 90];
const sortedNumbers = bubbleSort(numbers);
console.log(`المصفوفة الأصلية: ${numbers}`);
console.log(`المصفوفة مرتبة: ${sortedNumbers}`);''',
        'calculator': '''class Calculator {
    /**
     * آلة حاسبة بسيطة تدعم العمليات الأساسية
     */
    
    add(a, b) {
        return a + b;
    }
    
    subtract(a, b) {
        return a - b;
    }
    
    multiply(a, b) {
        return a * b;
    }
    
    divide(a, b) {
        if (b === 0) {
            throw new Error("لا يمكن القسمة على صفر");
        }
        return a / b;
    }
}

// استخدام الآلة الحاسبة
const calc = new Calculator();
console.log(`5 + 3 = ${calc.add(5, 3)}`);
console.log(`10 - 4 = ${calc.subtract(10, 4)}`);
console.log(`6 * 7 = ${calc.multiply(6, 7)}`);
console.log(`15 / 3 = ${calc.divide(15, 3)}`);'''
    }
}

@code_generator_bp.route('/models', methods=['GET'])
def get_models():
    """الحصول على قائمة النماذج المدعومة"""
    return jsonify({
        'success': True,
        'models': SUPPORTED_MODELS
    })

@code_generator_bp.route('/languages', methods=['GET'])
def get_languages():
    """الحصول على قائمة لغات البرمجة المدعومة"""
    all_languages = set()
    for model_info in SUPPORTED_MODELS.values():
        all_languages.update(model_info['languages'])
    
    return jsonify({
        'success': True,
        'languages': sorted(list(all_languages))
    })

@code_generator_bp.route('/generate', methods=['POST'])
def generate_code():
    """توليد الكود بناءً على الطلب"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        if not data:
            return jsonify({
                'success': False,
                'error': 'لم يتم إرسال بيانات'
            }), 400
        
        prompt = data.get('prompt', '').strip()
        model = data.get('model', '')
        language = data.get('language', '')
        
        if not prompt:
            return jsonify({
                'success': False,
                'error': 'يجب إدخال وصف للكود المطلوب'
            }), 400
        
        if not model or model not in SUPPORTED_MODELS:
            return jsonify({
                'success': False,
                'error': 'نموذج الذكاء الاصطناعي غير صحيح'
            }), 400
        
        if not language:
            return jsonify({
                'success': False,
                'error': 'يجب اختيار لغة البرمجة'
            }), 400
        
        # استخدام خدمة AI لتوليد الكود
        result = ai_service.generate_code(prompt, model, language)
        
        if result['success']:
            # حساب إحصائيات الكود
            lines_count = len(result['code'].split('\n'))
            chars_count = len(result['code'])
            accuracy = random.uniform(95, 99)
            
            return jsonify({
                'success': True,
                'data': {
                    'code': result['code'],
                    'model_used': model,
                    'language': language,
                    'prompt': prompt,
                    'stats': {
                        'processing_time': round(result['processing_time'], 2),
                        'lines_count': lines_count,
                        'chars_count': chars_count,
                        'accuracy': round(accuracy, 1),
                        'tokens_used': result.get('tokens_used', 0)
                    },
                    'timestamp': time.time(),
                    'fallback': result.get('fallback', False)
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': result.get('error', 'فشل في توليد الكود')
            }), 500
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'حدث خطأ في الخادم: {str(e)}'
        }), 500

def select_appropriate_code(prompt, language):
    """اختيار الكود المناسب بناءً على الطلب"""
    prompt_lower = prompt.lower()
    
    # تحديد نوع الكود المطلوب بناءً على الكلمات المفتاحية
    if any(word in prompt_lower for word in ['فيبوناتشي', 'fibonacci', 'متتالية']):
        code_type = 'fibonacci'
    elif any(word in prompt_lower for word in ['ترتيب', 'sort', 'sorting', 'bubble']):
        code_type = 'sorting'
    elif any(word in prompt_lower for word in ['حاسبة', 'calculator', 'آلة', 'عمليات']):
        code_type = 'calculator'
    else:
        # اختيار عشوائي إذا لم يتم التعرف على النوع
        code_type = random.choice(['fibonacci', 'sorting', 'calculator'])
    
    # الحصول على الكود المناسب
    if language in CODE_EXAMPLES and code_type in CODE_EXAMPLES[language]:
        return CODE_EXAMPLES[language][code_type]
    elif language == 'Python':
        return CODE_EXAMPLES['Python'][code_type]
    else:
        # إنشاء كود بسيط للغات غير المدعومة
        return generate_simple_code(language, code_type)

def generate_simple_code(language, code_type):
    """إنشاء كود بسيط للغات غير المدعومة"""
    if language == 'Java':
        return '''public class Example {
    public static void main(String[] args) {
        System.out.println("مرحباً من Java!");
        // الكود المولّد حسب الطلب
    }
}'''
    elif language == 'C++':
        return '''#include <iostream>
using namespace std;

int main() {
    cout << "مرحباً من C++!" << endl;
    // الكود المولّد حسب الطلب
    return 0;
}'''
    elif language == 'Go':
        return '''package main

import "fmt"

func main() {
    fmt.Println("مرحباً من Go!")
    // الكود المولّد حسب الطلب
}'''
    else:
        return f'''// كود {language} مولّد
// {code_type} implementation
// الكود المولّد حسب الطلب'''

@code_generator_bp.route('/validate', methods=['POST'])
def validate_code():
    """التحقق من صحة الكود"""
    try:
        data = request.get_json()
        code = data.get('code', '')
        language = data.get('language', '')
        
        if not code:
            return jsonify({
                'success': False,
                'error': 'لم يتم إرسال كود للتحقق منه'
            }), 400
        
        # محاكاة عملية التحقق
        time.sleep(0.5)
        
        # تحليل بسيط للكود
        lines = code.split('\n')
        non_empty_lines = [line for line in lines if line.strip()]
        
        # محاكاة نتائج التحقق
        is_valid = len(non_empty_lines) > 0
        syntax_errors = []
        warnings = []
        
        if not is_valid:
            syntax_errors.append("الكود فارغ")
        
        return jsonify({
            'success': True,
            'validation': {
                'is_valid': is_valid,
                'syntax_errors': syntax_errors,
                'warnings': warnings,
                'lines_analyzed': len(lines),
                'language': language
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'حدث خطأ في التحقق: {str(e)}'
        }), 500

