import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [prompt, setPrompt] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [selectedModel, setSelectedModel] = useState('starcoder');
  const [selectedLanguage, setSelectedLanguage] = useState('python');
  const [isGenerating, setIsGenerating] = useState(false);
  const [stats, setStats] = useState(null);

  const models = [
    { id: 'openai-codex', name: '🤖OpenAI Codex' },
    { id: 'code-llama', name: '🦙Code Llama' },
    { id: 'starcoder', name: '⭐StarCoder' },
    { id: 'deepseek-coder', name: '🔍DeepSeek Coder' },
    { id: 'chatgpt', name: '💬ChatGPT' },
    { id: 'claude', name: '🎭Claude' },
    { id: 'manus', name: '🚀Manus' },
  ];

  const languages = [
    'Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust',
    'PHP', 'Ruby', 'Swift', 'Kotlin', 'Dart', 'SQL', 'HTML', 'CSS'
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      alert('يرجى إدخال وصف للكود المطلوب');
      return;
    }

    setIsGenerating(true);
    setGeneratedCode('');
    setStats(null);

    try {
      const response = await fetch('http://localhost:5001/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt,
          model: selectedModel,
          language: selectedLanguage
        })
      });

      if (!response.ok) {
        throw new Error('فشل في توليد الكود');
      }

      const data = await response.json();
      
      if (data.success) {
        setGeneratedCode(data.code);
        setStats({
          generationTime: data.generation_time,
          linesCount: data.lines_count,
          accuracy: data.accuracy,
          model: data.model_used
        });
      } else {
        throw new Error(data.error || 'خطأ في توليد الكود');
      }
    } catch (error) {
      console.error('خطأ:', error);
      setGeneratedCode('// حدث خطأ في توليد الكود\n// يرجى المحاولة مرة أخرى');
      setStats({
        generationTime: 0,
        linesCount: 1,
        accuracy: 0,
        model: 'خطأ'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>AI Code Generator</h1>
        <p>مولد الأكواد بالذكاء الاصطناعي</p>
      </header>

      <nav className="navbar">
        <button>الرئيسية</button>
        <button>المولد</button>
        <button>الوثائق</button>
      </nav>

      <main className="main-content">
        <div className="input-section">
          <h2>وصف الكود المطلوب</h2>
          <textarea
            placeholder="اكتب وصفاً للكود المطلوب هنا..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          ></textarea>

          <div className="controls">
            <div className="control-group">
              <label>نموذج الذكاء الاصطناعي</label>
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
              >
                {models.map((model) => (
                  <option key={model.id} value={model.id}>
                    {model.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="control-group">
              <label>لغة البرمجة</label>
              <select
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
              >
                {languages.map((lang) => (
                  <option key={lang} value={lang.toLowerCase()}>
                    {lang}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button onClick={handleGenerate} disabled={isGenerating}>
            {isGenerating ? 'جاري التوليد...' : 'توليد الكود'}
          </button>
        </div>

        <div className="output-section">
          <h2>الكود المولّد</h2>
          <pre className="code-output">
            {generatedCode || 'سيظهر الكود المولّد هنا'}
          </pre>
          {stats && (
            <div className="stats">
              <p>وقت التوليد: {stats.generationTime} ثانية</p>
              <p>عدد الأسطر: {stats.linesCount}</p>
              <p>دقة الكود: {stats.accuracy}%</p>
              <p>النموذج المستخدم: {stats.model}</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;

